
def organize_files(path):
    import os
    import shutil
    imagens=('jpg','png','gif','ico')
    documentos=('docx','odt','txt','asm','csv','epub')
    programas=('.pdsprj','.c','iso','exe','py','dwf','xps','dwfx')
    zip=('zip', 'rar', 'tar', '7zip')
    audio = ('mp3', 'm4a', 'wav', 'ogg')
    videos=('mp4', 'AVI', 'wmv', 'mov')
    pdf=('pdf')
    pwp=('ppt','pptx','pptjpg','pptpng')
    exc=('xls','xlsx','odf')
    def create_file(nome):
        try:
            os.mkdir(path + nome)
        except FileExistsError:
            a=1
    def change_file(archive,file):
            shutil.move(path+'\\'+archive,path+file)
    os.chdir(path)
    files=os.listdir(path)
    for f in files :
        if f.endswith(zip):
            create_file(r'\zip')
            change_file(f,r'\zip')
        elif f.endswith(documentos):
            create_file(r'\documentos')
            change_file(f,r'\documentos')
        elif f.endswith(imagens):
            create_file('r\imagens')
            change_file(f,r'\imagens')
        elif f.endswith(videos):
            create_file(r'\videos')
            change_file(f,r'\videos')
        elif f.endswith(pdf):
            create_file('\pdfs')
            change_file(f,r'\pdfs')
        elif f.endswith(pwp):
            create_file(r'\powerpoint')
            change_file(f,r'\powerpoint')
        elif f.endswith(exc):
            create_file(r'\excel')
            change_file(f,r'\excel')
        elif f.endswith(programas):
            create_file(r'\programas')
            change_file(f,r'\programas')
        elif f.endswith(audio):
            create_file(r'\audio')
            change_file(f, r'\audio')